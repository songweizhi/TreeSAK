
'''

ALE4_op_dir_1_0.3
ALE4_op_dir_2_0.3
ALE4_op_dir_3_0.3
ALE4_op_dir_4_0.3
ALE4_op_dir_5_0.3

'''