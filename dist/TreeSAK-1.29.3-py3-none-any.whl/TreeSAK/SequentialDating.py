
SequentialDating_usage = '''
======================== SequentialDating example commands ========================

TreeSAK SequentialDating -h

===================================================================================
'''


def SequentialDating():

    pass


SequentialDating()
