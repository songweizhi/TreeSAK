

num = 40.00

num_formatted = str(num/100).replace('0.', '.')

print(num_formatted)
